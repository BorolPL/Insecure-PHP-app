# A Purposefully Insecure PHP Application

This is an example application built using Silex for routing to provide examples of SQL Injection, plain text passwords and XSS.

I haven't used Silex features on purpose to provide a basic PHP example.


Whatever you do **DO NOT USE THIS SITE IN PRODUCTION**.